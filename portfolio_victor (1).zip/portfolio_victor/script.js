// Atualiza automaticamente o ano no rodapé.
const elementoAno = document.getElementById("ano");
elementoAno.textContent = new Date().getFullYear();

// Fecha o menu mobile do Bootstrap após clicar em um link de navegação.
const linksMenu = document.querySelectorAll(".navbar-nav .nav-link");
const menu = document.getElementById("menu");

linksMenu.forEach((link) => {
  link.addEventListener("click", () => {
    if (menu.classList.contains("show")) {
      const menuBootstrap = bootstrap.Collapse.getOrCreateInstance(menu);
      menuBootstrap.hide();
    }
  });
});
