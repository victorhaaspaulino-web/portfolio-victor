PORTFÓLIO DE VICTOR

Arquivos:
- index.html: estrutura e conteúdo da página.
- style.css: estilos personalizados.
- script.js: interações simples.
- prompts.txt: registro dos prompts.
- descricao-ia.txt: descrição da IA utilizada.

Como abrir:
1. Extraia o arquivo ZIP.
2. Abra index.html em um navegador.
3. Para o Bootstrap funcionar, mantenha conexão com a internet (CDN).

Personalização importante:
- Troque "seuemail@exemplo.com" pelo e-mail correto.
- Revise os textos de apresentação e projetos para refletirem sua realidade.
- Você pode substituir os projetos de exemplo por trabalhos que realmente desenvolveu.
